#include "TZonnonParser.h"

using namespace std;

TZonnonParser::TZonnonParser()
{
}

TZonnonParser::~TZonnonParser()
{
}

std::string TZonnonParser::PrintParserResult(TParserResult pres)
{
	string res = "";
	if(pres.IsError)  //���� ������
	{
		res = "#PARSER ERROR IN POS: " + to_str(pres.ErrorPos);
	}
	else  //�����������
	{
		res = "OK";
	}
	return res;
}

TParserResult TZonnonParser::ParseIt(std::vector<TLexem> lex_str)  //��������� ������ �� ������ ������� ������������ ������
{
	TParserResult res;
	res.IsError = false;
	res.ErrorPos = 0;

	pos = 0;
	str = lex_str;
	if(E())  //������� �����������
	{
		if(pos < str.size()) //�������� ������ ������� � �����
		{
			res.IsError = true;
			res.ErrorPos = pos;
		}
	}
	else  //������� �������������
	{
		res.IsError = true;
		res.ErrorPos = pos;
	}

	return res;
}


/*
1 E -> LX_NUM_INT X Z W
2 E -> LX_NUM_REAL X Z W
3 E -> LX_ID G X Z W
4 E -> LX_LB E LX_RB X Z W
5 E -> LX_OP_NG F X Z W
6 E -> LX_OP_PS T Z W
7 E -> LX_OP_MS T Z W
*/
bool TZonnonParser::E()
{
	if(pos >= str.size())
	{
		return false;
	}

	switch(str[pos].lex_type)
	{
	case LX_NUM_INT: //1 E -> LX_NUM_INT X Z W
		{
			++pos;
			if(X())
			{
				if(Z())
				{
					if(W())
					{
						return true;
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_NUM_REAL: //2 E -> LX_NUM_REAL X Z W
		{
			++pos;
			if(X())
			{
				if(Z())
				{
					if(W())
					{
						return true;
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_ID: //3 E -> LX_ID G X Z W
		{
			++pos;
			if(G())
			{
				if(X())
				{
					if(Z())
					{
						if(W())
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_LB: //4 E -> LX_LB E LX_RB X Z W
		{
			++pos;
			if(E())
			{
				if(pos >= str.size())
				{
					return false;
				}
				if(str[pos].lex_type==LX_RB)
				{
					++pos;
					if(X())
					{
						if(Z())
						{
							if(W())
							{
								return true;
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_NG: //5 E -> LX_OP_NG F X Z W
		{
			++pos;
			if(F())
			{
				if(X())
				{
					if(Z())
					{
						if(W())
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_PS: //6 E -> LX_OP_PS T Z W
		{
			++pos;
			if(T())
			{
				if(Z())
				{
					if(W())
					{
						return true;
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_MS: //7 E -> LX_OP_MS T Z W
		{
			++pos;
			if(T())
			{
				if(Z())
				{
					if(W())
					{
						return true;
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	}
	return false;
}

/*
1 W ->
2 W -> LX_OP_EQ S
3 W -> LX_OP_NE S
4 W -> LX_OP_LT S
5 W -> LX_OP_LE S
6 W -> LX_OP_GT S
7 W -> LX_OP_GE S
*/
bool TZonnonParser::W()
{
	if(pos >= str.size())
	{
		return true; //1 W ->
	}

	switch(str[pos].lex_type)
	{
	case LX_OP_EQ: //2 W -> LX_OP_EQ S
		{
			++pos;
			if(S())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_NE: //3 W -> LX_OP_NE S
		{
			++pos;
			if(S())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_LT: //4 W -> LX_OP_LT S
		{
			++pos;
			if(S())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_LE: //5 W -> LX_OP_LE S
		{
			++pos;
			if(S())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_GT: //6 W -> LX_OP_GT S
		{
			++pos;
			if(S())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_GE: //7 W -> LX_OP_GE S
		{
			++pos;
			if(S())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	}
	return true;  //1 W ->
}

/*
1 S -> LX_NUM_INT X Z
2 S -> LX_NUM_REAL X Z
3 S -> LX_ID G X Z
4 S -> LX_LB E LX_RB X Z
5 S -> LX_OP_NG F X Z
6 S -> LX_OP_PS T Z
7 S -> LX_OP_MS T Z
*/
bool TZonnonParser::S()
{
	if(pos >= str.size())
	{
		return false;
	}

	switch(str[pos].lex_type)
	{
	case LX_NUM_INT: //1 S -> LX_NUM_INT X Z
		{
			++pos;
			if(X())
			{
				if(Z())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_NUM_REAL: //2 S -> LX_NUM_REAL X Z
		{
			++pos;
			if(X())
			{
				if(Z())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_ID: //3 S -> LX_ID G X Z
		{
			++pos;
			if(G())
			{
				if(X())
				{
					if(Z())
					{
						return true;
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_LB: //4 S -> LX_LB E LX_RB X Z
		{
			++pos;
			if(E())
			{
				if(pos >= str.size())
				{
					return false;
				}
				if(str[pos].lex_type==LX_RB)
				{
					++pos;
					if(X())
					{
						if(Z())
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_NG: //5 S -> LX_OP_NG F X Z
		{
			++pos;
			if(F())
			{
				if(X())
				{
					if(Z())
					{
						return true;
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_PS: //6 S -> LX_OP_PS T Z
		{
			++pos;
			if(T())
			{
				if(Z())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_MS: //7 S -> LX_OP_MS T Z
		{
			++pos;
			if(T())
			{
				if(Z())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	}
	return false;
}

/*
1 Z ->
2 Z -> LX_OP_PS T Z
3 Z -> LX_OP_MS T Z
4 Z -> LX_OP_OR T Z
*/
bool TZonnonParser::Z()
{
	if(pos >= str.size())
	{
		return true; //1 Z ->
	}

	switch(str[pos].lex_type)
	{
	case LX_OP_PS: //2 Z -> LX_OP_PS T Z
		{
			++pos;
			if(T())
			{
				if(Z())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_MS: //3 Z -> LX_OP_MS T Z
		{
			++pos;
			if(T())
			{
				if(Z())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_OR: //4 Z -> LX_OP_OR T Z
		{
			++pos;
			if(T())
			{
				if(Z())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	}
	return true; //1 Z ->
}

/*
1 T -> LX_NUM_INT X
2 T -> LX_NUM_REAL X
3 T -> LX_ID G X
4 T -> LX_LB E LX_RB X
5 T -> LX_OP_NG F X
*/
bool TZonnonParser::T()
{
	if(pos >= str.size())
	{
		return false;
	}

	switch(str[pos].lex_type)
	{
	case LX_NUM_INT: //1 T -> LX_NUM_INT X
		{
			++pos;
			if(X())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_NUM_REAL: //2 T -> LX_NUM_REAL X
		{
			++pos;
			if(X())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_ID: //3 T -> LX_ID G X
		{
			++pos;
			if(G())
			{
				if(X())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_LB: //4 T -> LX_LB E LX_RB X
		{
			++pos;
			if(E())
			{
				if(pos >= str.size())
				{
					return false;
				}
				if(str[pos].lex_type==LX_RB)
				{
					++pos;
					if(X())
					{
						return true;
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_NG: //5 T -> LX_OP_NG F X
		{
			++pos;
			if(F())
			{
				if(X())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	}
	return false;
}

/*
1 X ->
2 X -> LX_OP_AS T
3 X -> LX_OP_SL T
4 X -> LX_OP_DV T
5 X -> LX_OP_MD T
6 X -> LX_OP_AM T
*/
bool TZonnonParser::X()
{
	if(pos >= str.size())
	{
		return true; //1 X ->
	}

	switch(str[pos].lex_type)
	{
	case LX_OP_AS: //2 X -> LX_OP_AS T
		{
			++pos;
			if(T())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_SL: //3 X -> LX_OP_SL T
		{
			++pos;
			if(T())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_DV: //4 X -> LX_OP_DV T
		{
			++pos;
			if(T())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_MD: //5 X -> LX_OP_MD T
		{
			++pos;
			if(T())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_AM: //6 X -> LX_OP_AM T
		{
			++pos;
			if(T())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	}
	return true; //1 X ->
}

/*
1 F -> LX_NUM_INT
2 F -> LX_NUM_REAL
3 F -> LX_ID G 
4 F -> LX_LB E LX_RB
5 F -> LX_OP_NG F
*/
bool TZonnonParser::F()
{
	if(pos >= str.size())
	{
		return false;
	}

	switch(str[pos].lex_type)
	{
	case LX_NUM_INT: //1 F -> LX_NUM_INT
		{
			++pos;
			return true;
		} break;
	case LX_NUM_REAL: //2 F -> LX_NUM_REAL
		{
			++pos;
			return true;
		} break;
	case LX_ID: //3 F -> LX_ID G
		{
			++pos;
			if(G())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	case LX_LB: //4 F -> LX_LB E LX_RB
		{
			++pos;
			if(E())
			{
				if(pos >= str.size())
				{
					return false;
				}
				if(str[pos].lex_type==LX_RB)
				{
					++pos;
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_NG: //5 F -> LX_OP_NG F
		{
			++pos;
			if(F())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	}
	return false;
}

/*
1 G ->
2 G -> LX_LB H
*/
bool TZonnonParser::G()
{
	if(pos >= str.size())
	{
		return true; //1 G ->
	}

	switch(str[pos].lex_type)
	{
	case LX_LB: //2 G -> LX_LB H
		{
			++pos;
			if(H())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	}
	return true; //1 G ->
}

/*
1 H -> LX_RB
2 H -> LX_NUM_INT X Z W B LX_RB
3 H -> LX_NUM_REAL X Z W B LX_RB
4 H -> LX_ID G X Z W B LX_RB
5 H -> LX_LB E LX_RB X Z W B LX_RB
6 H -> LX_OP_NG F X Z W B LX_RB
7 H -> LX_OP_PS T Z W B LX_RB
8 H -> LX_OP_MS T Z W B LX_RB
*/
bool TZonnonParser::H()
{
	if(pos >= str.size())
	{
		return false;
	}

	switch(str[pos].lex_type)
	{
	case LX_RB: //1 H -> LX_RB
		{
			++pos;
			return true;
		} break;
	case LX_NUM_INT: //2 H -> LX_NUM_INT X Z W B LX_RB
		{
			++pos;
			if(X())
			{
				if(Z())
				{
					if(W())
					{
						if(B())
						{
							if(pos >= str.size())
							{
								return false;
							}
							if(str[pos].lex_type==LX_RB)
							{
								++pos;
								return true;
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_NUM_REAL: //3 H -> LX_NUM_REAL X Z W B LX_RB
		{
			++pos;
			if(X())
			{
				if(Z())
				{
					if(W())
					{
						if(B())
						{
							if(pos >= str.size())
							{
								return false;
							}
							if(str[pos].lex_type==LX_RB)
							{
								++pos;
								return true;
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_ID: //4 H -> LX_ID G X Z W B LX_RB
		{
			++pos;
			if(G())
			{
				if(X())
				{
					if(Z())
					{
						if(W())
						{
							if(B())
							{
								if(pos >= str.size())
								{
									return false;
								}
								if(str[pos].lex_type==LX_RB)
								{
									++pos;
									return true;
								}
								else
								{
									return false;
								}
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_LB: //5 H -> LX_LB E LX_RB X Z W B LX_RB
		{
			++pos;
			if(E())
			{
				if(pos >= str.size())
				{
					return false;
				}
				if(str[pos].lex_type==LX_RB)
				{
					++pos;
					if(X())
					{
						if(Z())
						{
							if(W())
							{
								if(B())
								{
									if(pos >= str.size())
									{
										return false;
									}
									if(str[pos].lex_type==LX_RB)
									{
										++pos;
										return true;
									}
									else
									{
										return false;
									}
								}
								else
								{
									return false;
								}
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_NG: //6 H -> LX_OP_NG F X Z W B LX_RB
		{
			++pos;
			if(F())
			{
				if(X())
				{
					if(Z())
					{
						if(W())
						{
							if(B())
							{
								if(pos >= str.size())
								{
									return false;
								}
								if(str[pos].lex_type==LX_RB)
								{
									++pos;
									return true;
								}
								else
								{
									return false;
								}
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_PS: //7 H -> LX_OP_PS T Z W B LX_RB
		{
			++pos;
			if(T())
			{
				if(Z())
				{
					if(W())
					{
						if(B())
						{
							if(pos >= str.size())
							{
								return false;
							}
							if(str[pos].lex_type==LX_RB)
							{
								++pos;
								return true;
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_MS: //8 H -> LX_OP_MS T Z W B LX_RB
		{
			++pos;
			if(T())
			{
				if(Z())
				{
					if(W())
					{
						if(B())
						{
							if(pos >= str.size())
							{
								return false;
							}
							if(str[pos].lex_type==LX_RB)
							{
								++pos;
								return true;
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	}
	return false;
}

/*
1 A -> LX_NUM_INT X Z W B
2 A -> LX_NUM_REAL X Z W B
3 A -> LX_ID G X Z W B
4 A -> LX_LB E LX_RB X Z W B
5 A -> LX_OP_NG F X Z W B
6 A -> LX_OP_PS T Z W B
7 A -> LX_OP_MS T Z W B
*/
bool TZonnonParser::A()
{
	if(pos >= str.size())
	{
		return false;
	}

	switch(str[pos].lex_type)
	{
	case LX_NUM_INT: //1 A -> LX_NUM_INT X Z W B
		{
			++pos;
			if(X())
			{
				if(Z())
				{
					if(W())
					{
						if(B())
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_NUM_REAL: //2 A -> LX_NUM_REAL X Z W B
		{
			++pos;
			if(X())
			{
				if(Z())
				{
					if(W())
					{
						if(B())
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_ID: //3 A -> LX_ID G X Z W B
		{
			++pos;
			if(G())
			{
				if(X())
				{
					if(Z())
					{
						if(W())
						{
							if(B())
							{
								return true;
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_LB: //4 A -> LX_LB E LX_RB X Z W B
		{
			++pos;
			if(E())
			{
				if(pos >= str.size())
				{
					return false;
				}
				if(str[pos].lex_type==LX_RB)
				{
					++pos;
					if(X())
					{
						if(Z())
						{
							if(W())
							{
								if(B())
								{
									return true;
								}
								else
								{
									return false;
								}
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_NG: //5 A -> LX_OP_NG F X Z W B
		{
			++pos;
			if(F())
			{
				if(X())
				{
					if(Z())
					{
						if(W())
						{
							if(B())
							{
								return true;
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_PS: //6 A -> LX_OP_PS T Z W B
		{
			++pos;
			if(T())
			{
				if(Z())
				{
					if(W())
					{
						if(B())
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	case LX_OP_MS: //7 A -> LX_OP_MS T Z W B
		{
			++pos;
			if(T())
			{
				if(Z())
				{
					if(W())
					{
						if(B())
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} break;
	}
	return false;
}

/*
1 B ->
2 B -> LX_CM A
*/
bool TZonnonParser::B()
{
	if(pos >= str.size())
	{
		return true; //1 B ->
	}

	switch(str[pos].lex_type)
	{
	case LX_CM: //2 B -> LX_CM A
		{
			++pos;
			if(A())
			{
				return true;
			}
			else
			{
				return false;
			}
		} break;
	}
	return true; //1 B ->
}
