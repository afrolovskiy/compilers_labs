#ifndef __ruconH__
#define __ruconH__

#include <string>
#include <windows.h>
#include <stdlib.h>

inline std::string ru(std::string s)
{
	char* rs = (char*)calloc(s.size()+1, sizeof(char));
	CharToOemA(s.c_str(), rs);
	std::string res(rs);
	free(rs);
	return res;
}

inline bool is_blank_delim(char c)
{
	unsigned char uc = c;
	if((uc >= 0 && uc <= 9) || (uc >= 11 && uc <= 32) || (uc >= 127 && uc <= 167) || 
	   (uc >= 169 && uc <= 183) || (uc >= 186 && uc <= 191))
		return true;
	return false;
}

#endif
