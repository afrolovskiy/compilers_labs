#include "TZonnonLex.h"
#include "str.h"

using namespace std;

TZonnonLex::TZonnonLex()
{
	//������ ������������ �������
	TFastSet<unsigned char> V;
	for(unsigned char c = 'A'; c<= 'Z'; c++) V.AddElement(c);
	for(unsigned char c = 'a'; c<= 'z'; c++) V.AddElement(c);
	for(unsigned char c = '0'; c<= '9'; c++) V.AddElement(c);
	V.AddElement('.');
	V.AddElement('+');
	V.AddElement('-');
	V.AddElement('_');
	V.AddElement('=');
	V.AddElement('#');
	V.AddElement('<');
	V.AddElement('>');
	V.AddElement('*');
	V.AddElement('/');
	V.AddElement('&');
	V.AddElement('~');
	V.AddElement('(');
	V.AddElement(')');
	V.AddElement(',');

	//������� ����������� ����������
	Lex = new TLex(V);

	//��������� �������-�����������
	Lex->AddLexSep(' ');
	Lex->AddLexSep('\t');

	//������� ��������������� ���������� ���������
	TRegEx dig = TRegEx();
	for(char c = '0'; c <= '9'; c++)			dig = dig + TRegEx(c);
	
	TRegEx let = TRegEx();
	for(char c = 'a'; c <= 'z'; c++)			let = let + TRegEx(c);
	for(char c = 'A'; c <= 'Z'; c++)			let = let + TRegEx(c);

	//��������� �������
	Lex->AddLexRegEx(TLexemRegEx(LX_CM, TRegEx(',')));
	Lex->AddLexRegEx(TLexemRegEx(LX_LB, TRegEx('(')));
	Lex->AddLexRegEx(TLexemRegEx(LX_RB, TRegEx(')')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_NG, TRegEx('~')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_MS, TRegEx('-')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_PS, TRegEx('+')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_AM, TRegEx('&')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_SL, TRegEx('/')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_AS, TRegEx('*')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_GE, TRegEx('>') * TRegEx('=')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_GT, TRegEx('>')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_LE, TRegEx('<') * TRegEx('=')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_LT, TRegEx('<')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_NE, TRegEx('#')));
	Lex->AddLexRegEx(TLexemRegEx(LX_OP_EQ, TRegEx('=')));
	Lex->AddLexRegEx(TLexemRegEx(LX_NUM_INT, dig * (*dig)));
	Lex->AddLexRegEx(TLexemRegEx(LX_NUM_REAL, 
		(dig * (*dig) * TRegEx('.') * (*dig)) +
		(dig * (*dig) * TRegEx('.') * (*dig) * (TRegEx('E') + TRegEx('D')) * dig * (*dig)) + 
		(dig * (*dig) * TRegEx('.') * (*dig) * (TRegEx('E') + TRegEx('D')) * TRegEx('+') * dig * (*dig)) +
		(dig * (*dig) * TRegEx('.') * (*dig) * (TRegEx('E') + TRegEx('D')) * TRegEx('-') * dig * (*dig))
	));
	Lex->AddLexRegEx(TLexemRegEx(LX_ID, 
		(let + TRegEx('_')) * (*(let + TRegEx('_') + dig))
	));

	//��������� �������� �����
	Lex->AddLexReplace(TLexemReplace(LX_OP_DV, "DIV"));
	Lex->AddLexReplace(TLexemReplace(LX_OP_MD, "MOD"));
	Lex->AddLexReplace(TLexemReplace(LX_OP_OR, "OR"));
}

TZonnonLex::~TZonnonLex()
{
	delete Lex;
}

TLexResult TZonnonLex::LexIt(std::string str)  //����������� ������ ������
{
	return Lex->LexIt(str);
}

std::string TZonnonLex::PrintLexResult(TLexResult lres)
{
	string res = "";
	if(lres.is_error)  //������ �������
	{
		res = "#LEXER ERROR IN POS: " + to_str(lres.error_pos);
	}
	else  //������ ������
	{
		if(lres.lex_out.size() > 0)
		{
			for(size_t i = 0, sz_i = lres.lex_out.size(); i < sz_i; i++)
			{
				string slex_type = "";
				switch(lres.lex_out[i].lex_type)
				{
				case LX_NUM_INT:	slex_type = "LX_NUM_INT ";	break;
				case LX_NUM_REAL:	slex_type = "LX_NUM_REAL";	break;
				case LX_ID:			slex_type = "LX_ID      ";	break;
				case LX_OP_DV:		slex_type = "LX_OP_DV   ";	break;
				case LX_OP_MD:		slex_type = "LX_OP_MD   ";	break;
				case LX_OP_OR:		slex_type = "LX_OP_OR   ";	break;
				case LX_OP_EQ:		slex_type = "LX_OP_EQ   ";	break;
				case LX_OP_NE:		slex_type = "LX_OP_NE   ";	break;
				case LX_OP_LT:		slex_type = "LX_OP_LT   ";	break;
				case LX_OP_LE:		slex_type = "LX_OP_LE   ";	break;
				case LX_OP_GT:		slex_type = "LX_OP_GT   ";	break;
				case LX_OP_GE:		slex_type = "LX_OP_GE   ";	break;
				case LX_OP_AS:		slex_type = "LX_OP_AS   ";	break;
				case LX_OP_SL:		slex_type = "LX_OP_SL   ";	break;
				case LX_OP_AM:		slex_type = "LX_OP_AM   ";	break;
				case LX_OP_PS:		slex_type = "LX_OP_PS   ";	break;
				case LX_OP_MS:		slex_type = "LX_OP_MS   ";	break;
				case LX_OP_NG:		slex_type = "LX_OP_NG   ";	break;
				case LX_LB:			slex_type = "LX_LB      ";	break;
				case LX_RB:			slex_type = "LX_RB      ";	break;
				case LX_CM:			slex_type = "LX_CM      ";	break;
				default:			slex_type = "LX_???     ";	break;
				}
				res = res + slex_type + "    pos: " + to_str(i) + "\t" "    " + lres.lex_out[i].lex_val + "\n";
			}
		}
		else
		{
			res = "#LEXER ERROR: EMPTY STRING";
		}
	}
	return res;
}
