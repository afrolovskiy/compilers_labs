#include "TRegEx.h"

using namespace std;

TRegEx::TRegEx()
{
}

TRegEx::TRegEx(char a)
{
	TRegExChar ch;
	ch.chtype = CH_TERM;
	ch.ch.term = a;
	regex.push_back(ch);
	rpn_regex.push_back(ch);
}

TRegEx::~TRegEx()
{
}

TRegExStr TRegEx::GetRegEx()
{
	return regex;
}
TRegExStr TRegEx::GetRegExRPN()
{
	return rpn_regex;
}
std::string TRegEx::GetRegExStr()
{
	string res;
	for(TRegExStr::iterator i = regex.begin(); i != regex.end(); i++)
	{
		switch(i->chtype)
		{
		case CH_TERM:
			res = res + i->ch.term;
			break;
		case CH_SYS:
			switch(i->ch.sys)
			{
			case CH_LB:	res = res + "(";	break;
			case CH_RB:	res = res + ")";	break;
			case CH_P:	res = res + "+";	break;
			case CH_M:	res = res + ".";	break;
			case CH_I:	res = res + "*";	break;
			case CH_E:	res = res + "#";	break;
			}
			break;
		}
	}
	return res;
}
std::string TRegEx::GetRegExRPNStr()
{
	string res;
	for(TRegExStr::iterator i = rpn_regex.begin(); i != rpn_regex.end(); i++)
	{
		switch(i->chtype)
		{
		case CH_TERM:
			res = res + i->ch.term;
			break;
		case CH_SYS:
			switch(i->ch.sys)
			{
			case CH_LB:	res = res + "(";	break;
			case CH_RB:	res = res + ")";	break;
			case CH_P:	res = res + "+";	break;
			case CH_M:	res = res + ".";	break;
			case CH_I:	res = res + "*";	break;
			case CH_E:	res = res + "#";	break;
			}
			break;
		}
	}
	return res;
}

TRegEx TRegEx::operator*()  //��������
{
	TRegEx res;
	if(regex.size()==0)  //O* = e
	{
		TRegExChar ch;
		ch.chtype = CH_SYS;
		ch.ch.sys = CH_E;
		res.regex.push_back(ch);
		res.rpn_regex.push_back(ch);
	}
	else if(regex.size()==1 && regex[0].chtype==CH_SYS && regex[0].ch.sys==CH_E)  //e* = e
	{
		res.regex = regex;
		res.rpn_regex = rpn_regex;
	}
	else
	{			
		if(regex.size()>=4 && 
			regex[0].chtype==CH_SYS && regex[0].ch.sys==CH_LB &&
			regex[regex.size()-2].chtype==CH_SYS && regex[regex.size()-2].ch.sys==CH_RB &&
			regex[regex.size()-1].chtype==CH_SYS && regex[regex.size()-1].ch.sys==CH_I)  //x [*]-> ((x)*)* = (x)*
		{
			res.regex = regex;
			res.rpn_regex = rpn_regex;
		}
		else  //x [*]-> (x)*
		{
			TRegExChar ch;		ch.chtype = CH_SYS;
			ch.ch.sys = CH_LB;	res.regex.push_back(ch);
			for(TRegExStr::iterator i = regex.begin(); i != regex.end(); i++)
				res.regex.push_back(*i);
			for(TRegExStr::iterator i = rpn_regex.begin(); i != rpn_regex.end(); i++)
				res.rpn_regex.push_back(*i);
			ch.ch.sys = CH_RB;	res.regex.push_back(ch);
			ch.ch.sys = CH_I;	res.regex.push_back(ch);
			res.rpn_regex.push_back(ch);
		}
	}
	return res;
}


TRegEx operator*(TRegEx a, TRegEx b)  //����������
{
	TRegEx res;
	TRegExStr A = a.GetRegEx(), B = b.GetRegEx();
	TRegExStr rpnA = a.GetRegExRPN(), rpnB = b.GetRegExRPN();
	if(A.size()==0 || B.size()==0)  //x [rm]-> xO = O   //x [lm]-> Ox = O
	{
		;//O
	}
	else if(A.size()==1 && A[0].chtype==CH_SYS && A[0].ch.sys==CH_E)  //x [lm]-> ex = x
	{
		res.regex = B;
		res.rpn_regex = rpnB;
	}
	else if(B.size()==1 && B[0].chtype==CH_SYS && B[0].ch.sys==CH_E)  //x [rm]-> xe = x
	{
		res.regex = A;
		res.rpn_regex = rpnA;
	}
	else  //x [rm]-> (x)(a)		//x [lm]-> (a)(x)
	{
		TRegExChar ch;		ch.chtype = CH_SYS;
		ch.ch.sys = CH_LB; res.regex.push_back(ch);
		for(TRegExStr::iterator i = A.begin(); i != A.end(); i++)
			res.regex.push_back(*i);
		for(TRegExStr::iterator i = rpnA.begin(); i != rpnA.end(); i++)
			res.rpn_regex.push_back(*i);
		ch.ch.sys = CH_RB; res.regex.push_back(ch);
		ch.ch.sys = CH_M; res.regex.push_back(ch);
		ch.ch.sys = CH_LB; res.regex.push_back(ch);
		for(TRegExStr::iterator i = B.begin(); i != B.end(); i++)
			res.regex.push_back(*i);
		for(TRegExStr::iterator i = rpnB.begin(); i != rpnB.end(); i++)
			res.rpn_regex.push_back(*i);
		ch.ch.sys = CH_RB; res.regex.push_back(ch);
		ch.ch.sys = CH_M; res.rpn_regex.push_back(ch);
	}
	return res;
}




TRegEx operator+(TRegEx a, TRegEx b)  //�����������
{
	TRegEx res;
	TRegExStr A = a.GetRegEx(), B = b.GetRegEx();
	TRegExStr rpnA = a.GetRegExRPN(), rpnB = b.GetRegExRPN();
	if(B.size()==0)  //x [+]-> x + O = x
	{
		res.regex = A;
		res.rpn_regex = rpnA;
	}
	else if(A.size()==0)  //x [+]-> O + x = x
	{
		res.regex = B;
		res.rpn_regex = rpnB;
	}
	else if(A == B)  //x [+]-> x + x = x
	{
		res.regex = A;
		res.rpn_regex = rpnA;
	}
	else 
	{
		bool is_sum = true;
		if(A.size()>=4 && 
			A[0].chtype==CH_SYS && A[0].ch.sys==CH_LB &&
			A[A.size()-2].chtype==CH_SYS && A[A.size()-2].ch.sys==CH_RB &&
			A[A.size()-1].chtype==CH_SYS && A[A.size()-1].ch.sys==CH_I)  //x [+]-> (x)* + x = (x)*
		{
			TRegExStr sA = A;	sA.erase(sA.begin());	sA.pop_back();	sA.pop_back();
			if(sA == B)
			{
				res.regex = A;
				res.rpn_regex = rpnA;
				is_sum = false;
			}
		}
		else if(B.size()>=4 && 
				B[0].chtype==CH_SYS && B[0].ch.sys==CH_LB &&
				B[B.size()-2].chtype==CH_SYS && B[B.size()-2].ch.sys==CH_RB &&
				B[B.size()-1].chtype==CH_SYS && B[B.size()-1].ch.sys==CH_I)  //x [+]-> x + (x)* = (x)*
		{
			TRegExStr sB = B;	sB.erase(sB.begin());	sB.pop_back();	sB.pop_back();
			if(sB == A)
			{
				res.regex = B;
				res.rpn_regex = rpnB;
				is_sum = false;
			}
		}
		if(is_sum)  //x [+]-> x + a		//x [+]-> a + x
		{
			TRegExChar ch;
			for(TRegExStr::iterator i = A.begin(); i != A.end(); i++)
				res.regex.push_back(*i);
			for(TRegExStr::iterator i = rpnA.begin(); i != rpnA.end(); i++)
				res.rpn_regex.push_back(*i);
			ch.chtype = CH_SYS;		ch.ch.sys = CH_P;	res.regex.push_back(ch);
			for(TRegExStr::iterator i = B.begin(); i != B.end(); i++)
				res.regex.push_back(*i);
			for(TRegExStr::iterator i = rpnB.begin(); i != rpnB.end(); i++)
				res.rpn_regex.push_back(*i);
			ch.chtype = CH_SYS;		ch.ch.sys = CH_P;	res.rpn_regex.push_back(ch);
		}
	}
	return res;
}

bool operator==(TRegEx a, TRegEx b)   //���������
{
	if(a.regex == b.regex && a.rpn_regex == b.rpn_regex)
		return true;
	return false;
}
