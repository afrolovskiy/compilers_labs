#ifndef __TRegExH__
#define __TRegExH__

#include <vector>
#include <string>

/*
-------------
--------------------------------a + b = b + a
--------------------------------O* = e
--------------------------------a + (b + c) = (a + b) + c
--------------------------------a(bc) = (ab)c
--------------------------------a(b+c) = ab + ac
--------------------------------(a+b)c = ac + bc
--------------------------------ae = ea = a
--------------------------------Oa = aO = O
--------------------------------a* = a* + a
--------------------------------(a*)* = a*
--------------------------------a+a = a
--------------------------------a + O = a
-------------

O* = e
e* = e
x [*]-> (x)*
x [*]-> ((x)*)* = (x)*

x [+]-> x + a
x [+]-> x + O = x
x [+]-> x + e
x [+]-> x + x = x
x [+]-> (x)* + x = (x)*

x [rm]-> xO = O
x [lm]-> Ox = O
x [rm]-> xe = x
x [lm]-> ex = x
x [rm]-> (x)a
x [lm]-> a(x)

*/

enum TChType : char {CH_TERM, CH_SYS};
enum TChSys : char {CH_LB, CH_RB, CH_P, CH_M, CH_I, CH_E};

struct TRegExChar
{
	TChType chtype;
	union 
	{
		char term;
		TChSys sys;
	} ch;
};
inline bool operator==(const TRegExChar a, const TRegExChar b)
{
	if(a.chtype==b.chtype && ((a.chtype==CH_TERM && a.ch.term==b.ch.term) || (a.chtype==CH_SYS && a.ch.sys==b.ch.sys)))
		return true;
	return false;
}

typedef std::vector<TRegExChar> TRegExStr;

//���������� ���������
class TRegEx
{
private:
	TRegExStr regex;
	TRegExStr rpn_regex;
protected:
public:
	TRegEx();
	TRegEx(char a);
	~TRegEx();
	TRegExStr GetRegEx();
	TRegExStr GetRegExRPN();
	std::string GetRegExStr();
	std::string GetRegExRPNStr();
	TRegEx operator*();  //��������
	friend TRegEx operator*(TRegEx a, TRegEx b);  //����������
	friend TRegEx operator+(TRegEx a, TRegEx b);  //�����������
	friend bool operator==(TRegEx a, TRegEx b);   //���������
};

TRegEx operator*(TRegEx a, TRegEx b);  //����������
TRegEx operator+(TRegEx a, TRegEx b);  //�����������
bool operator==(TRegEx a, TRegEx b);   //���������

#endif
