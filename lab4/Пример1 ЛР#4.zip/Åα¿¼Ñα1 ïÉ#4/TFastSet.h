#ifndef __TFastSetH__
#define __TFastSetH__

#include <vector>

template<typename T>
class TFastSet
{
private:
	std::vector<size_t> v;
	size_t pos;
protected:
public:
	TFastSet() {}
	TFastSet(size_t sz) 
	{
		v.resize(sz, 0);
	}
	~TFastSet() {}
	bool empty()
	{
		for(size_t i = 0, sz = v.size(); i < sz; i++)
		{
			if(v[i]==1)
				return false;
		}
		return true;
	}
	size_t begin()
	{
		pos = 0;
		if(v.size() > 0 && v[pos]==1)
			return pos;
		return next();
	}
	size_t end()
	{
		return v.size();
	}
	size_t next()
	{
		size_t i = 0;
		for(size_t i = pos+1, sz = v.size(); i < sz; i++)
		{
			if(v[i]==1)
			{
				pos = i;
				return pos;
			}
		}
		pos = v.size();
		return pos;
	}
	void AddElement(T e)
	{
		if((size_t)e < v.size())
		{
			v[(size_t)e] = 1;
		}
		else
		{
			v.resize((size_t)e + 1, 0);
			v[(size_t)e] = 1;
		}
	}
	void DelElement(T e)
	{
		if((size_t)e < v.size())
		{
			v[(size_t)e] = 0;
		}
		else
		{
			v.resize((size_t)e + 1, 0);
		}
	}
	bool IsElem(T e)
	{
		if((size_t)e < v.size())
		{
			if(v[(size_t)e]==1)
				return true;
			else
				return false;
		}
		else
		{
			v.resize((size_t)e + 1, 0);
		}
		return false;
	}
	
	TFastSet<T> operator*(const TFastSet<T>& b)
	{
		TFastSet<T> res;
		size_t sz_a = v.size();
		size_t sz_b = b.v.size();
		if(sz_a <= sz_b)
		{
			res.v.resize(sz_a, 0);
			for(size_t i = 0; i < sz_a; i++)
			{
				res.v[i] = v[i] & b.v[i];
			}
		}
		else
		{
			res.v.resize(sz_b, 0);
			for(size_t i = 0; i < sz_b; i++)
			{
				res.v[i] = v[i] & b.v[i];
			}
		}
		return res;
	}

	TFastSet<T> operator+(const TFastSet<T>& b)
	{
		TFastSet<T> res;
		size_t sz_a = v.size();
		size_t sz_b = b.v.size();
		if(sz_a >= sz_b)
		{
			res.v = v;
			for(size_t i = 0; i < sz_b; i++)
			{
				res.v[i] = v[i] | b.v[i];
			}
		}
		else
		{
			res.v = b.v;
			for(size_t i = 0; i < sz_a; i++)
			{
				res.v[i] = v[i] | b.v[i];
			}
		}
		return res;
	}

	TFastSet<T> operator-(const TFastSet<T>& b)
	{
		TFastSet<T> res;
		size_t sz_a = v.size();
		size_t sz_b = b.v.size();
		if(sz_a >= sz_b)
		{
			res.v = v;
			for(size_t i = 0; i < sz_b; i++)
			{
				res.v[i] = v[i] & ~b.v[i];
			}
		}
		else
		{
			res.v = b.v;
			for(size_t i = 0; i < sz_a; i++)
			{
				res.v[i] = v[i] & ~b.v[i];
			}
		}
		return res;
	}
	
	bool operator<(const TFastSet<T>& b)
	{
		return v<b.v;
	}
	
	bool operator<=(const TFastSet<T>& b)
	{
		return v<=b.v;
	}
	
	bool operator==(const TFastSet<T>& b)
	{
		return v==b.v;
	}

	T GetLastElem()
	{
		T res;
		for(size_t i = 0, sz = v.size(); i < sz; i++)
		{
			if(v[i]==1)
				res = (T)i;
		}
		return res;
	}
};


#endif
