#ifndef __strH__
#define __strH__

#include <string>
#include <sstream>

template<typename T>
std::string to_str(T val)
{
	std::ostringstream oss;
	oss << val;
	return oss.str();
}

template<typename T>
T from_str(const std::string &s)
{
	std::istringstream iss(s);
	T res;
	iss >> res;
	return res;
}

inline std::string vector_to_str(std::vector<char> v)
{
	std::string res;
	for(std::vector<char>::iterator i = v.begin(); i != v.end(); i++)
		res = res + (*i);
	return res;
}

inline std::vector<char> str_to_vector(std::string s)
{
	std::vector<char> res;
	for(std::string::iterator i = s.begin(); i != s.end(); i++)
		res.push_back(*i);
	return res;
}

inline std::string trim(std::string s, char c = ' ')
{
	std::string res = "";
	int t1 = s.find_first_not_of(c);
	int t2 = s.find_last_not_of(c);
	for(int i = t1; i <= t2 && t1 >= 0 && t2 >= 0; i++)
		res = res + s[i];
	return res;
}

#endif
