#ifndef __TZonnonParserH__
#define __TZonnonParserH__

#include <string>
#include <vector>
#include "TZonnonLex.h"

/*
V = {op_eq, op_ne, op_lt, op_le, op_gt, op_ge, op_ps, op_ms, op_or, op_as, op_sl, op_dv, op_md, op_am, num_int, num_real, lb, rb, op_ng, id, cm}
N = {E, W, S, Z, T, X, F, G, H, A, B}
S = E
P:


E -> num_int X Z W
E -> num_real X Z W
E -> id G X Z W
E -> lb E rb X Z W
E -> op_ng F X Z W
E -> op_ps T Z W
E -> op_ms T Z W

W ->
W -> op_eq S
W -> op_ne S
W -> op_lt S
W -> op_le S
W -> op_gt S
W -> op_ge S

S -> num_int X Z
S -> num_real X Z
S -> id G X Z
S -> lb E rb X Z
S -> op_ng F X Z
S -> op_ps T Z
S -> op_ms T Z

Z ->
Z -> op_ps T Z
Z -> op_ms T Z
Z -> op_or T Z

T -> num_int X
T -> num_real X
T -> id G X
T -> lb E rb X
T -> op_ng F X

X ->
X -> op_as T
X -> op_sl T
X -> op_dv T
X -> op_md T
X -> op_am T

F -> num_int
F -> num_real
F -> id G 
F -> lb E rb
F -> op_ng F

G ->
G -> lb H

H -> rb
H -> num_int X Z W B rb
H -> num_real X Z W B rb
H -> id G X Z W B rb
H -> lb E rb X Z W B rb
H -> op_ng F X Z W B rb
H -> op_ps T Z W B rb
H -> op_ms T Z W B rb

A -> num_int X Z W B
A -> num_real X Z W B
A -> id G X Z W B
A -> lb E rb X Z W B
A -> op_ng F X Z W B
A -> op_ps T Z W B
A -> op_ms T Z W B

B ->
B -> cm A

*/

struct TParserResult
{
	bool IsError;     //���� ������?
	size_t ErrorPos;  //��� ���� ������, ���� ��� ����
};

class TZonnonParser
{
private:
	size_t pos;
	std::vector<TLexem> str;
	bool E();
	bool W();
	bool S();
	bool Z();
	bool T();
	bool X();
	bool F();
	bool G();
	bool H();
	bool A();
	bool B();
protected:
public:
	TZonnonParser();
	~TZonnonParser();
	TParserResult ParseIt(std::vector<TLexem> lex_str);  //��������� ������ �� ������ ������� ������������ ������
	static std::string PrintParserResult(TParserResult pres);
};

#endif
